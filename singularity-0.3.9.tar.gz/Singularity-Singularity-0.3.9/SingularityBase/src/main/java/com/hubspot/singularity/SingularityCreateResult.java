package com.hubspot.singularity;

public enum SingularityCreateResult {
  CREATED, EXISTED;
}
