package com.hubspot.singularity;

public enum SingularityDeleteResult {
  DELETED, DIDNT_EXIST;
}
