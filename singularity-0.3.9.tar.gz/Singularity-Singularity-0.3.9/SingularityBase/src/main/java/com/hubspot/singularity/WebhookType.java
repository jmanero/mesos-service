package com.hubspot.singularity;

public enum WebhookType {

  TASK, REQUEST, DEPLOY;

}
