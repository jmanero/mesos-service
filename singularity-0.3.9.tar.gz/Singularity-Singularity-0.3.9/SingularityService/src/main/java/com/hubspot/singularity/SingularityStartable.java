package com.hubspot.singularity;

public interface SingularityStartable {

  void start();

}
