package com.hubspot.singularity.runner.base.shared;

public interface SingularityDriver {

  void startAndWait();

  void shutdown();

}
