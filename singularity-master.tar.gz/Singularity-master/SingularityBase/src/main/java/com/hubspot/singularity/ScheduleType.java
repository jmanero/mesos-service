package com.hubspot.singularity;

public enum ScheduleType {

  CRON, QUARTZ;

}
