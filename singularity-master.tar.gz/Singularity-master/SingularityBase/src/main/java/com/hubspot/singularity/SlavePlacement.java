package com.hubspot.singularity;

public enum SlavePlacement {

  SEPARATE, OPTIMISTIC, GREEDY

}
